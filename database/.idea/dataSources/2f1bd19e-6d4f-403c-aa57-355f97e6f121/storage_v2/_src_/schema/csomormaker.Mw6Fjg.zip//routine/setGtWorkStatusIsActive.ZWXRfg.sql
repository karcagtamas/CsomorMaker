create
    definer = root@localhost procedure setGtWorkStatusIsActive(IN _workerId int, IN _workId int)
BEGIN
        DECLARE _active boolean;
        DECLARE _gtId int(11);
        SELECT isActive INTO _active FROM gtworkworkerswitch WHERE worker = _workerId AND work = _workId;

        IF _active
        THEN
            SET _active = FALSE;
        ELSE
            SET _active = TRUE;
        END IF;
        UPDATE gtworkworkerswitch SET isActive = _active WHERE worker = _workerId AND work = _workId;
        SELECT gt INTO _gtId FROM gtworks WHERE id = _workId;
        CALL setGtReadyStatus(_gtId, FALSE);
    END;

