create
    definer = root@localhost procedure updateGtMember(IN _gtId int, IN _userId int, IN _roleId int)
BEGIN
      UPDATE usergtswitch SET role = _roleId WHERE gt = _gtId AND user = _userId;
    END;

