create
    definer = root@localhost procedure setReadyEvent(IN _id int)
BEGIN
      UPDATE events SET ready = TRUE WHERE id = _id;
    END;

