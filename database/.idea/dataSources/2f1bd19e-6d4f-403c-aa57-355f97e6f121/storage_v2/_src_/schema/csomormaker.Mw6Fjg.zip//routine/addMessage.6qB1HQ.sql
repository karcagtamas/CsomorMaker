create
    definer = root@localhost procedure addMessage(IN _eventId int, IN _sender int, IN _message text)
BEGIN
     INSERT INTO eventmessages (sender, event, message)
       VALUES (_sender, _eventId, _message);
    END;

