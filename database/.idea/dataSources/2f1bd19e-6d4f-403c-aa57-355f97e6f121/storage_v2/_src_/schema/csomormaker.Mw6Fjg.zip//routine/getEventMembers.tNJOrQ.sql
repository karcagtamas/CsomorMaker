create
    definer = root@localhost procedure getEventMembers(IN _id int)
BEGIN
     SELECT users.id, users.name, users.username, usereventswitch.role AS roleId, usereventswitch.connectionDate, usereventswitch.event, eventroles.accessLevel, eventroles.name AS role FROM users
      INNER JOIN usereventswitch ON users.id = usereventswitch.user
      INNER JOIN eventroles ON usereventswitch.role = eventroles.id
      WHERE usereventswitch.event = _id;
    END;

