create definer = root@localhost trigger team_members
    after INSERT
    on eventteammembers
    for each row
BEGIN
    DECLARE _eventId int(11) DEFAULT 0;
    UPDATE eventteams SET members = members + 1 WHERE id = NEW.team;
    SELECT event INTO _eventId FROM eventteams
      WHERE id = NEW.team;
    UPDATE events set currentPlayers = currentPlayers + 1 WHERE id = _eventId;

  END;

