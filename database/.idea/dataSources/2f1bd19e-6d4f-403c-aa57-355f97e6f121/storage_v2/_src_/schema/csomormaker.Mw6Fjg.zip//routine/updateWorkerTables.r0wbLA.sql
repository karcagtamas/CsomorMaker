create
    definer = root@localhost procedure updateWorkerTables(IN _workerId int, IN _eventId int)
BEGIN
      DECLARE _days int(2);
      DECLARE _currentDay int(2) DEFAULT 0;
      DECLARE _startHour int(2);
      DECLARE _endHour int(11);
      DELETE FROM eventworkertables WHERE worker = _workerId AND event = _eventId;

      SELECT days, startHour, endHour  INTO _days, _startHour, _endHour FROM events WHERE id = _eventId;

      WHILE _days <> _currentDay OR _startHour <> _endHour DO
        INSERT INTO eventworkertables (day, hour, worker, event)
        VALUES (_currentDay, _startHour, _workerId, _eventId);

        SET _startHour = _startHour + 1;
        IF _startHour = 24
          THEN SET _startHour = 0;
          SET _currentDay = _currentDay + 1;
        END IF;
      END WHILE;

    END;

