create definer = root@localhost trigger work_update
    after UPDATE
    on gtworks
    for each row
BEGIN
    CALL setGtReadyStatus(NEW.id, FALSE);
  END;

