create
    definer = root@localhost procedure getMessages(IN _eventId int)
BEGIN
     SELECT * FROM eventmessages WHERE event = _eventId ORDER BY dateOfSent LIMIT 200;
    END;

