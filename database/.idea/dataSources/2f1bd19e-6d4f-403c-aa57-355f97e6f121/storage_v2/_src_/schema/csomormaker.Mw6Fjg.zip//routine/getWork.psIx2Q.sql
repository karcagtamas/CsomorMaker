create
    definer = root@localhost procedure getWork(IN _id int)
BEGIN
     SELECT * FROM eventworks WHERE id = _id;
    END;

