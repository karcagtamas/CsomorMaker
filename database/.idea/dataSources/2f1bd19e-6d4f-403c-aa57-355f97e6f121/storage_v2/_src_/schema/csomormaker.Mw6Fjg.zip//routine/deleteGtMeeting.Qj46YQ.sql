create
    definer = root@localhost procedure deleteGtMeeting(IN _id int)
BEGIN
      DELETE FROM gtmeetings WHERE id = _id;
    END;

