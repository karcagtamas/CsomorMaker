create
    definer = root@localhost procedure updatePayOut(IN _id int, IN _name varchar(75), IN _type int, IN _cost decimal,
                                                    IN _source varchar(100), IN _destination varchar(100))
BEGIN
     UPDATE eventpayouts SET name = _name, type = _type, cost = _cost, source = _source, destination = _destination WHERE id = _id;
    END;

