create
    definer = root@localhost procedure deleteEventTeam(IN _teamId int)
BEGIN
      DELETE FROM eventteams WHERE id = _teamId;
    END;

