create definer = root@localhost trigger gt_meetings
    after INSERT
    on gtmeetings
    for each row
BEGIN
     INSERT INTO gtmeetingswitch (user, meeting)
       SELECT * FROM (
        SELECT usergtswitch.user FROM usergtswitch
        WHERE usergtswitch.gt = NEW.gt) AS T1
      CROSS JOIN (SELECT NEW.id) AS T2;
  END;

