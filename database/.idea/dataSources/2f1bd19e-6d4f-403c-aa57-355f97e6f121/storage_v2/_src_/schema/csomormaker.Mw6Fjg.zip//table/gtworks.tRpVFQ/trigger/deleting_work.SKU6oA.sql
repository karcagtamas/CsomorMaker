create definer = root@localhost trigger deleting_work
    after DELETE
    on gtworks
    for each row
BEGIN
    DELETE FROM gtworkworkerswitch WHERE work = OLD.id;
    DELETE FROM gtworktables WHERE work = OLD.id;
    CALL setGtReadyStatus(OLD.id, FALSE);
  END;

