create
    definer = root@localhost procedure getGtMessages(IN _gtId int)
BEGIN
    SELECT gtmessages.id, gtmessages.sender AS senderId, gtmessages.gt, gtmessages.dateOfSent, gtmessages.message, users.name AS sender FROM gtmessages
      INNER JOIN users ON users.id = gtmessages.sender
      WHERE gtmessages.gt = _gtId
    ORDER BY gtmessages.dateOfSent LIMIT 200;
  END;

