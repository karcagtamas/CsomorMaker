create
    definer = root@localhost procedure countOfCostAndDeposit(IN _teamId int)
BEGIN
     DECLARE _paid int(10) DEFAULT 0;
     DECLARE _deposit int(10) DEFAULT 0;

     SELECT COUNT(id) INTO _paid FROM eventteammembers WHERE team = _teamId AND isPaidCost;
     SELECT COUNT(id) INTO _deposit FROM eventteammembers WHERE team = _teamId AND isPaidDeposit;

      SELECT _paid AS countOfCost, _deposit AS countOfDeposit;
    END;

