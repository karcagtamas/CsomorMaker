create
    definer = root@localhost procedure getPayOuts(IN _eventId int)
BEGIN
     SELECT eventpayouts.name, eventpayouts.id, eventpayouts.eventId, eventpayouts.cost, eventpayouts.type AS typeId, eventpayouttypes.name AS type, eventpayouttypes.isOut, eventpayouts.source, eventpayouts.destination FROM eventpayouts
     INNER JOIN eventpayouttypes ON eventpayouts.type = eventpayouttypes.id
     WHERE eventpayouts.eventId = _eventId;
    END;

