create
    definer = root@localhost procedure login(IN _userId int)
BEGIN
    UPDATE users SET lastLogin = NOW() WHERE id = _userId;
    END;

