create
    definer = root@localhost procedure getGtPayouts(IN _gtId int)
BEGIN
    SELECT gtpayouts.id, gtpayouts.name, gtpayouts.gt, gtpayouts.type AS typeId, gtpayouts.cost, eventpayouttypes.name AS type, eventpayouttypes.isOut, gtpayouts.source AS `from`, gtpayouts.destination AS `to` FROM gtpayouts
    INNER JOIN eventpayouttypes ON eventpayouttypes.id = gtpayouts.type
    WHERE gtpayouts.gt = _gtId
    ORDER BY gtpayouts.type;
  END;

