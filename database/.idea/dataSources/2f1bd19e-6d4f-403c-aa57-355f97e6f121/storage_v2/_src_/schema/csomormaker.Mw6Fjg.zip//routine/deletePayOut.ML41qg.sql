create
    definer = root@localhost procedure deletePayOut(IN _id int)
BEGIN
     DELETE FROM eventpayouts WHERE id = _id;
    END;

