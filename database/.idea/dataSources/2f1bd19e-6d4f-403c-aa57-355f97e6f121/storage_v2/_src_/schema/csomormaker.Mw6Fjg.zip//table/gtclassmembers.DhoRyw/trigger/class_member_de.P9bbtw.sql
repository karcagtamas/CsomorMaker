create definer = root@localhost trigger class_member_de
    after DELETE
    on gtclassmembers
    for each row
BEGIN
    UPDATE gtclasses set members = members - 1 WHERE id = OLD.class;
  END;

