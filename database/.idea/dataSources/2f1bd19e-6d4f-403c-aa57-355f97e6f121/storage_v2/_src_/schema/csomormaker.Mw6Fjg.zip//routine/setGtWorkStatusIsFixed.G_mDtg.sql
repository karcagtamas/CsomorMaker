create
    definer = root@localhost procedure setGtWorkStatusIsFixed(IN _workerId int, IN _workId int)
BEGIN
      DECLARE _fix boolean;
      DECLARE _gtId int(11);
        SELECT isFixed INTO _fix FROM gtworkworkerswitch WHERE worker = _workerId AND work = _workId;

        IF _fix
        THEN
            SET _fix = FALSE;
        ELSE
            SET _fix = TRUE;
        END IF;
        UPDATE gtworkworkerswitch SET isFixed = _fix WHERE worker = _workerId AND work = _workId;
        SELECT gt INTO _gtId FROM gtworks WHERE id = _workId;
        CALL setGtReadyStatus(_gtId, FALSE);
    END;

