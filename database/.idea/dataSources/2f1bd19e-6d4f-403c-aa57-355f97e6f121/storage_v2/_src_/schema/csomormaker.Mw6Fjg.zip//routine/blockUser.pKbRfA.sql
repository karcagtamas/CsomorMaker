create
    definer = root@localhost procedure blockUser(IN _userId int, IN _status tinyint(1))
BEGIN
        UPDATE users SET blocked = _status WHERE id = _userId;
    END;

