create
    definer = root@localhost procedure getLowGtWorkers(IN _gtId int)
BEGIN
      SELECT usergtswitch.gt, users.id AS id, users.username, users.name, eventroles.accessLevel, usergtswitch.isGeneratable FROM usergtswitch
      INNER JOIN users ON users.id = usergtswitch.user
      INNER JOIN eventroles ON eventroles.id = usergtswitch.role
      WHERE usergtswitch.gt = _gtId AND eventroles.accessLevel = 1
      ORDER BY users.name;
    END;

