create
    definer = root@localhost procedure deleteGtQuestion(IN _id int)
BEGIN
      DELETE FROM gtquestions WHERE id = _id;
    END;

