create definer = root@localhost trigger event_update
    after UPDATE
    on events
    for each row
BEGIN
    DECLARE _updater varchar(100);
    SELECT name INTO _updater FROM users WHERE id = NEW.lastUpdater;

    IF NEW.isDisabled <> OLD.isDisabled
      THEN CALL addNotification(CONCAT(NEW.name, ' eseményed acrhiválva lett ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
      ELSE IF NEW.isLocked <> OLD.isLocked AND NEW.isLocked
           THEN CALL addNotification(CONCAT(NEW.name, ' eseményed zárolva lett ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
           ELSE IF NEW.isLocked <> OLD.isLocked AND NOT NEW.isLocked
                THEN CALL addNotification(CONCAT(NEW.name, ' eseményed fel lett oldva ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
                ELSE IF NEW.members = OLD.members AND NEW.ready = OLD.ready
                  THEN CALL addNotification(CONCAT(NEW.name, ' eseményed sikeresen frissítve lett ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
                  END IF;
                END IF;
           END IF;
    END IF;
  END;

