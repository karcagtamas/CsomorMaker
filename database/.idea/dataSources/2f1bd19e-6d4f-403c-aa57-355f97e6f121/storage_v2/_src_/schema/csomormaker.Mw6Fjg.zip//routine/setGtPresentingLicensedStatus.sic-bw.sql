create
    definer = root@localhost procedure setGtPresentingLicensedStatus(IN _gtId int, IN _user1 int, IN _user2 int)
BEGIN
    DECLARE _licensed boolean;
     SELECT isLicensed INTO _licensed FROM gtpresentingsswitch WHERE gt = _gtId AND presenter = _user1 AND presented = _user2;

     IF _licensed
      THEN
        SET _licensed = FALSE;
      ELSE
        SET _licensed = TRUE;
      END IF;
      UPDATE gtpresentingsswitch SET isLicensed = _licensed WHERE gt = _gtId AND presenter = _user1 AND presented = _user2;
  END;

