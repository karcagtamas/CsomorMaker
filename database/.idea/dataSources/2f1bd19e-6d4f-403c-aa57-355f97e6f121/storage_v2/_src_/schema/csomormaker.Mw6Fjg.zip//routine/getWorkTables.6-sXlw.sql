create
    definer = root@localhost procedure getWorkTables(IN _id int)
BEGIN
     SELECT eventworktables.day, eventworktables.hour, eventworktables.work AS workId, eventworks.name AS work, eventworktables.isActive, eventworktables.worker AS workerId, users.name AS worker FROM eventworktables
      INNER JOIN eventworks ON eventworktables.work = eventworks.id
      LEFT JOIN users ON eventworktables.worker = users.id
    WHERE eventworktables.work = _id
    ORDER BY eventworktables.day, eventworktables.hour;
    END;

