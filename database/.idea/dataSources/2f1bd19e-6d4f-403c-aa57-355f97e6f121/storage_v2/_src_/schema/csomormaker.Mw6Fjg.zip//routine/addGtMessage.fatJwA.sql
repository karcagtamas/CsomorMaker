create
    definer = root@localhost procedure addGtMessage(IN _gtId int, IN _sender int, IN _message text)
BEGIN
    INSERT INTO gtmessages(gt, sender, message)
      VALUES(_gtId, _sender, _message);
  END;

