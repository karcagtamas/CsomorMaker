create
    definer = root@localhost procedure getRoles()
BEGIN
      SELECT * FROM roles;
    END;

