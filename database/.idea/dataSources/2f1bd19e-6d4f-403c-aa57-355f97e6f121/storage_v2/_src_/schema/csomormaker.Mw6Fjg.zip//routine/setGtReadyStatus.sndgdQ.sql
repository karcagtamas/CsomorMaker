create
    definer = root@localhost procedure setGtReadyStatus(IN _gtId int, IN _value tinyint(1))
BEGIN
      UPDATE gts SET ready = _value WHERE id = _gtId;
    END;

