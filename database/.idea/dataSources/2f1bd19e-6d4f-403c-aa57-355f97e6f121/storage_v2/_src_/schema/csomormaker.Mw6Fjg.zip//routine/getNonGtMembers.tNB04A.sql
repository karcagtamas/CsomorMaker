create
    definer = root@localhost procedure getNonGtMembers(IN _gtId int)
BEGIN
       SELECT users.id, users.username, users.name, users.role AS roleId, roles.name AS role FROM users
        INNER JOIN roles ON users.role = roles.id
      WHERE users.id NOT IN (
      SELECT user as id FROM usergtswitch
      WHERE gt = _gtId
      ) ORDER BY users.name;
    END;

