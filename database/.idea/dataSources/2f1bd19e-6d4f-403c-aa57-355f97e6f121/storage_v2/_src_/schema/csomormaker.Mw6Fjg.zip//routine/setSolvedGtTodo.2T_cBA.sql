create
    definer = root@localhost procedure setSolvedGtTodo(IN _todoId int)
BEGIN
    UPDATE gttodoes SET isSolved = TRUE WHERE id = _todoId;
  END;

