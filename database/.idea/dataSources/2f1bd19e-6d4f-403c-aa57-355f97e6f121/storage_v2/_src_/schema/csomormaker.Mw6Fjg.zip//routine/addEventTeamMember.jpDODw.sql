create
    definer = root@localhost procedure addEventTeamMember(IN _teamId int, IN _name varchar(100))
BEGIN
      INSERT INTO eventteammembers (name, team)
  VALUES (_name, _teamId);
    END;

