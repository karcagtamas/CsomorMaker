create
    definer = root@localhost procedure setWorkerTableIsAvaiable(IN _day int(2), IN _hour int(2), IN _worker int, IN _eventId int)
BEGIN
     DECLARE _isAvaiable boolean;
     SELECT isAvaiable INTO _isAvaiable FROM eventworkertables WHERE day = _day AND hour = _hour AND worker = _worker AND event = _eventId;

     IF _isAvaiable
      THEN
        SET _isAvaiable = FALSE;
      ELSE
        SET _isAvaiable = TRUE;
      END IF;
      UPDATE eventworkertables SET isAvaiable = _isAvaiable WHERE day = _day AND hour = _hour AND worker = _worker AND event = _eventId;
      CALL setUnReadyEvent(_eventId);
    END;

