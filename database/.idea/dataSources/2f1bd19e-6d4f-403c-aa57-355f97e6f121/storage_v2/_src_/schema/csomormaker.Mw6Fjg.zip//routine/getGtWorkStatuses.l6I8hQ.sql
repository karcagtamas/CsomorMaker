create
    definer = root@localhost procedure getGtWorkStatuses(IN _workerId int, IN _gtId int)
BEGIN
      SELECT users.id AS workerId, users.name AS worker, users.username, gtworks.id AS workId, gtworks.name as work, gtworkworkerswitch.isActive, gtworkworkerswitch.isBoss, gtworkworkerswitch.isFixed from gtworkworkerswitch
      INNER JOIN users ON users.id = gtworkworkerswitch.worker
      INNER JOIN gtworks ON gtworks.id = gtworkworkerswitch.work
      WHERE gtworkworkerswitch.worker = _workerId AND gtworks.gt = _gtId;
    END;

