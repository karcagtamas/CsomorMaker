create
    definer = root@localhost procedure deleteNews(IN _id int)
BEGIN
      DELETE FROM news WHERE id = _id;
    END;

