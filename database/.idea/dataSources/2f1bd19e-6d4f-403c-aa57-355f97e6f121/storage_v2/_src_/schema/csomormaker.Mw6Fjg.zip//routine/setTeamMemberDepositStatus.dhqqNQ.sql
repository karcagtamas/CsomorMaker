create
    definer = root@localhost procedure setTeamMemberDepositStatus(IN _teammemberId int)
BEGIN
     DECLARE _isPaid boolean;
     SELECT isPaidDeposit INTO _isPaid FROM eventteammembers WHERE id = _teammemberId;

     IF _isPaid
      THEN
        SET _isPaid = FALSE;
      ELSE
        SET _isPaid = TRUE;
      END IF;
      UPDATE eventteammembers SET isPaidDeposit = _isPaid WHERE id = _teammemberId;
    END;

