create
    definer = root@localhost procedure updateGtWork(IN _workId int, IN _name varchar(100), IN _day int(2),
                                                    IN _start int(2), IN _end int(2), IN _workers int(3))
BEGIN
      UPDATE gtworks SET name = _name, day = _day, startHour = _start, endHour = _end, workerCount = _workers
      WHERE id = _workId;
    END;

