create
    definer = root@localhost procedure updateUserEvenetRole(IN _userId int, IN _eventId int, IN _roleId int)
BEGIN
        UPDATE usereventswitch SET role = _roleId WHERE user = _userId AND event = _eventId;
     END;

