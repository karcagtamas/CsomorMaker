create
    definer = root@localhost procedure getEventTeamMembers(IN _teamId int)
BEGIN
      SELECT * FROM eventteammembers
      WHERE team = _teamId;
    END;

