create
    definer = root@localhost procedure updateGtQuestion(IN _id int, IN _updater int, IN _question varchar(255))
BEGIN
      UPDATE gtquestions SET question = _question, lastUpdater = _updater, lastUpdate = NOW() WHERE id = _id;
    END;

