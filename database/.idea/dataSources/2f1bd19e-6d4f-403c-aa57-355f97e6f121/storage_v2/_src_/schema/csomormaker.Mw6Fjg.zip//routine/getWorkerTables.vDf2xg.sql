create
    definer = root@localhost procedure getWorkerTables(IN _id int, IN _eventId int)
BEGIN
     SELECT eventworkertables.day, eventworkertables.hour, eventworkertables.work AS workId, eventworks.name AS work, eventworkertables.isAvaiable, eventworkertables.worker AS workerId, users.name AS worker FROM eventworkertables
      LEFT JOIN eventworks ON eventworkertables.work = eventworks.id
      INNER JOIN users ON eventworkertables.worker = users.id
    WHERE eventworkertables.worker = _id AND eventworkertables.event = _eventId
    ORDER BY eventworkertables.day, eventworkertables.hour;
    END;

