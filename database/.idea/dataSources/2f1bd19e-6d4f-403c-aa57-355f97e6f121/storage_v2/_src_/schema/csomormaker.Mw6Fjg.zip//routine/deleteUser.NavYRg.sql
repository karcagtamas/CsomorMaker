create
    definer = root@localhost procedure deleteUser(IN _id int)
BEGIN
     DELETE FROM users WHERE id = _id;
    END;

