create definer = root@localhost trigger team_members_de
    after DELETE
    on eventteammembers
    for each row
BEGIN
    DECLARE _eventId int(11) DEFAULT 0;
    UPDATE eventteams SET members = members - 1 WHERE id = OLD.team;
    SELECT event INTO _eventId FROM eventteams
      WHERE id = OLD.team;
    UPDATE events set currentPlayers = currentPlayers - 1 WHERE id = _eventId;

  END;

