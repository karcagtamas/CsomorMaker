create
    definer = root@localhost procedure countOfAllCost(IN _eventId int)
BEGIN
     DECLARE _cost int(11) DEFAULT 0;
     DECLARE _deposit int(11) DEFAULT 0;
     SELECT COUNT(eventteammembers.id) INTO _cost FROM eventteammembers
      INNER JOIN eventteams ON eventteams.id = eventteammembers.team
      WHERE eventteams.event = _eventId AND eventteammembers.isPaidCost;
     SELECT COUNT(eventteammembers.id) INTO _deposit FROM eventteammembers
      INNER JOIN eventteams ON eventteams.id = eventteammembers.team
      WHERE eventteams.event = _eventId AND NOT eventteammembers.isPaidCost AND eventteammembers.isPaidDeposit;
     SELECT _cost AS countOfCosts, _deposit AS countOfDeposits;
    END;

