create
    definer = root@localhost procedure deleteMessage(IN _id int)
BEGIN
     DELETE FROM eventmessages WHERE id = _id;
    END;

