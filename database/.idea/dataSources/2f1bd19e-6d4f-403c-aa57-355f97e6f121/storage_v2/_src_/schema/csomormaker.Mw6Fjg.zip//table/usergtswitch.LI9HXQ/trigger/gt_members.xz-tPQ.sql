create definer = root@localhost trigger gt_members
    after INSERT
    on usergtswitch
    for each row
BEGIN
    DECLARE gt int(4);
    DECLARE role varchar(100);

    DECLARE _days int(2);
    DECLARE _currentDay int(2) DEFAULT 1;
    DECLARE _x int(2) DEFAULT 0;

    SELECT year INTO gt FROM gts WHERE id = NEW.gt;
    SELECT name INTO role FROM eventroles WHERE id = NEW.role;
    CALL addNotification(CONCAT('Felvettek a következő gólyatáborba: ', gt, CONCAT(' mint ', role, '!')), NEW.user);

    UPDATE gts SET members = members + 1 WHERE id = NEW.gt;
    INSERT INTO gtworkworkerswitch (work, worker, gt)
       SELECT * FROM (
        SELECT gtworks.id FROM gtworks
        WHERE gtworks.gt = NEW.gt) AS T1
    CROSS JOIN (SELECT NEW.user) AS T2
    CROSS JOIN (SELECT NEW.gt) AS T3;

      CALL setGtReadyStatus(NEW.gt, FALSE);
      DELETE FROM gtworkertables WHERE worker = NEW.user AND gt = NEW.gt;

      SELECT days INTO _days FROM gts WHERE id = NEW.gt;

      WHILE _days + 1 <> _currentDay DO
        SET _x = 0;
        WHILE _x <> 24 DO
            INSERT INTO gtworkertables (worker, day, hour, gt)
            VALUES (NEW.user, _currentDay, _x, NEW.gt);
            SET _x = _x + 1;
          END WHILE;
        SET _currentDay = _currentDay + 1;
      END WHILE;

      INSERT INTO gtmeetingswitch (meeting, user)
       SELECT * FROM (
        SELECT gtmeetings.id FROM gtmeetings
        WHERE gtmeetings.gt = NEW.gt) AS T1
      CROSS JOIN (SELECT NEW.user) AS T2;

      INSERT IGNORE INTO gtpresentingsswitch(presenter, presented, gt)
        SELECT * FROM (
          SELECT usergtswitch.user FROM usergtswitch
          WHERE usergtswitch.gt = NEW.gt
          ) AS T1
        CROSS JOIN (SELECT * FROM (
          SELECT usergtswitch.user FROM usergtswitch
          WHERE usergtswitch.gt = NEW.gt
          )AS T) AS T2
        CROSS JOIN (SELECT NEW.gt) AS T3;
  END;

