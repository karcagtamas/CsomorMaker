create
    definer = root@localhost procedure setGtWorkerStatusGeneratable(IN _gtId int, IN _workerId int)
BEGIN
      DECLARE _generatable boolean;
        SELECT isGeneratable INTO _generatable FROM usergtswitch WHERE gt = _gtId AND user = _workerId;

        IF _generatable
        THEN
            SET _generatable = FALSE;
        ELSE
            SET _generatable = TRUE;
        END IF;
        UPDATE usergtswitch u SET isGeneratable = _generatable WHERE gt = _gtId AND user = _workerId;
        CALL setGtReadyStatus(_gtId, FALSE);
    END;

