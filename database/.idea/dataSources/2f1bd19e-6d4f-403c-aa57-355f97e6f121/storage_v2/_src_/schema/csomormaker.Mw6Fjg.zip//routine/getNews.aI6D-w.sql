create
    definer = root@localhost procedure getNews()
BEGIN
      SELECT news.id, news.text, news.date, news.creater AS createrId, users.name AS creater, news.lastUpdate, news.lastUpdater AS lastUpdaterId, u2.name AS lastUpdater FROM news
      INNER JOIN users ON news.creater = users.id
      INNER JOIN users u2 ON news.lastUpdater = u2.id
      ORDER BY news.lastUpdate DESC;
    END;

