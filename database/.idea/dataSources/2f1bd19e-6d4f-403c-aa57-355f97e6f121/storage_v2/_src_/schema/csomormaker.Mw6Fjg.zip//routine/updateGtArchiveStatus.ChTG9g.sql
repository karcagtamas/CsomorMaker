create
    definer = root@localhost procedure updateGtArchiveStatus(IN _gtId int, IN _status tinyint(1))
BEGIN
        UPDATE gts SET isDisabled = _status WHERE id = _gtId;
    END;

