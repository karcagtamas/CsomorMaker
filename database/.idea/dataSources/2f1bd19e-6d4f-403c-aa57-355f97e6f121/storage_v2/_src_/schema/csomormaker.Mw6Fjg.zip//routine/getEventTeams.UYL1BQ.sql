create
    definer = root@localhost procedure getEventTeams(IN _event int)
BEGIN
      SELECT eventteams.id, eventteams.name, eventteams.event, eventteams.members, eventteams.creationDate, eventteams.hasResponsibilityPaper, eventteams.teamLeader AS teamLeaderId, eventteammembers.name AS teamLeader, eventteams.isPaidFixCost, eventteams.isPaidFixDeposit FROM eventteams
        LEFT JOIN eventteammembers ON eventteammembers.id = eventteams.teamLeader
      WHERE event = _event;
    END;

