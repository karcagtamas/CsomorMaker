create
    definer = root@localhost procedure updateUser(IN _id int, IN _name varchar(100), IN _tShirtSize varchar(6),
                                                  IN _allergy text, IN _class varchar(10))
BEGIN
     UPDATE users SET name = _name, tShirtSize = _tShirtSize, allergy = _allergy, class = _class WHERE id = _id;
    END;

