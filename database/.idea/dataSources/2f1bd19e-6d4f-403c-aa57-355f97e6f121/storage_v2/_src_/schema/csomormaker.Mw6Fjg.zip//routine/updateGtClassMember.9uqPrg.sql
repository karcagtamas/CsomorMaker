create
    definer = root@localhost procedure updateGtClassMember(IN _memberId int, IN _name varchar(100),
                                                           IN _description text, IN _allergy text,
                                                           IN _tShirtSize varchar(6))
BEGIN
    UPDATE gtclassmembers SET name = _name, description = _description, allergy = _allergy, tShirtSize = _tShirtSize WHERE id = _memberId;
  END;

