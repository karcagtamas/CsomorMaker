create
    definer = root@localhost procedure addUser(IN _username varchar(100), IN _email varchar(255),
                                               IN _password varchar(100))
BEGIN
     INSERT INTO users(username, email, name, password)
      VALUES(_username, _email, _username, _password);
    END;

