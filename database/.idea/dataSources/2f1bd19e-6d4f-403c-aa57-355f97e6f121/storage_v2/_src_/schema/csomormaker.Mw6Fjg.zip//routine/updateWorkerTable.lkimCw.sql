create
    definer = root@localhost procedure updateWorkerTable(IN _worker int, IN _event int, IN _day int(2), IN _hour int,
                                                         IN _work int)
BEGIN
      UPDATE eventworkertables SET work = _work WHERE worker = _worker AND event = _event AND day = _day AND hour = _hour;
    END;

