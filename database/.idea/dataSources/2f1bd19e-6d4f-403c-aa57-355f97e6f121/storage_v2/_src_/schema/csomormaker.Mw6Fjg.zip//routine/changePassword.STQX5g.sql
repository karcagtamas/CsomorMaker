create
    definer = root@localhost procedure changePassword(IN _id int, IN _password varchar(100))
BEGIN
     UPDATE users SET password = _password WHERE id = _id;
    END;

