create
    definer = root@localhost procedure getEventTodoes(IN _eventId int)
BEGIN
      SELECT * FROM eventtodoes WHERE event = _eventId
      ORDER BY isSolved, importance;
    END;

