create
    definer = root@localhost procedure getGtTodoes(IN _gtId int)
BEGIN
    SELECT * FROM gttodoes
      WHERE gt = _gtId
    ORDER BY isSolved, importance, date DESC;
  END;

