create
    definer = root@localhost procedure getHash(IN _username varchar(50))
BEGIN
      SELECT password AS hash, id AS userId FROM users
        WHERE username = _username AND NOT blocked;
    END;

