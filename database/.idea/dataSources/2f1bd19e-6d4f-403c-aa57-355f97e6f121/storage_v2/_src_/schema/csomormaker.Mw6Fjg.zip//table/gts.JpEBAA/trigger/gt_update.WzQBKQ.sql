create definer = root@localhost trigger gt_update
    after UPDATE
    on gts
    for each row
BEGIN
    DECLARE _updater varchar(100);
    
    DECLARE _days int(2) DEFAULT NEW.days;
    DECLARE _currentDay int(2) DEFAULT 1;
    DECLARE _x int(2) DEFAULT 0;

    SELECT name INTO _updater FROM users WHERE id = NEW.lastUpdater;
      
      IF NEW.isLocked <> OLD.isLocked AND NEW.isLocked
         THEN CALL addNotification(CONCAT(NEW.year, ' gólyatáborod zárolva lett ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
          ELSE IF NEW.isLocked <> OLD.isLocked AND NOT NEW.isLocked
               THEN CALL addNotification(CONCAT(NEW.year, ' gólyatáborod fel lett oldva ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
               ELSE IF NEW.members = OLD.members AND NEW.ready = OLD.ready
               THEN CALL addNotification(CONCAT(NEW.year, ' gólyatáborod sikeresen frissítve lett ', CONCAT(_updater, ' felhasználó által!')), NEW.creater);
                END IF;
            END IF;
      END IF;

    IF NEW.days <> OLD.days
      THEN

    DELETE FROM gtworkertables WHERE gt = NEW.id;

      SELECT days INTO _days FROM gts WHERE id = NEW.id;

      WHILE _days + 1 <> _currentDay DO
        SET _x = 0;
        WHILE _x <> 24 DO
            INSERT INTO gtworkertables (worker, day, hour, gt)
              SELECT * FROM (
                SELECT users.id FROM users
                INNER JOIN usergtswitch ON users.id = usergtswitch.user
                WHERE usergtswitch.gt = NEW.id) AS T1
                CROSS JOIN (SELECT _currentDay) AS T2
                CROSS JOIN (SELECT _x) AS T3
                CROSS JOIN (SELECT NEW.id) AS T4;
            SET _x = _x + 1;
          END WHILE;
        SET _currentDay = _currentDay + 1;
      END WHILE;
     END IF;
  END;

