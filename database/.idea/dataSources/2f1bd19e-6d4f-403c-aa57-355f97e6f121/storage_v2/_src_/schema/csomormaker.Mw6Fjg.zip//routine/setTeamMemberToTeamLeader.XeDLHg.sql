create
    definer = root@localhost procedure setTeamMemberToTeamLeader(IN _teamId int, IN _memberId int)
BEGIN
      UPDATE eventteams SET teamLeader = _memberId WHERE id = _teamId;
  END;

