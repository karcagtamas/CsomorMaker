create
    definer = root@localhost procedure deleteGtClass(IN _classId int)
BEGIN
    DELETE FROM gtclasses WHERE id = _classId;
  END;

