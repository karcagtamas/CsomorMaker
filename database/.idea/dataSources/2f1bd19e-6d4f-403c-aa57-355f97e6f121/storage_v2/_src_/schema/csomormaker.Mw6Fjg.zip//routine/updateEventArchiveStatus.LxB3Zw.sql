create
    definer = root@localhost procedure updateEventArchiveStatus(IN _eventId int, IN _status tinyint(1))
BEGIN
        UPDATE events SET isDisabled = _status WHERE id = _eventId;
    END;

