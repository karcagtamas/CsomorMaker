create
    definer = root@localhost procedure updateGtPayout(IN _payoutId int, IN _name varchar(75), IN _type int,
                                                      IN _cost decimal, IN _from varchar(50), IN _to varchar(50))
BEGIN
    UPDATE gtpayouts SET name = _name, type = _type, cost = _cost, source = _from, destination = _to WHERE id = _payoutId;
  END;

