create
    definer = root@localhost procedure getGtMeetingMembers(IN _meetingId int)
BEGIN
      SELECT gtmeetingswitch.user AS userId, gtmeetingswitch.meeting, gtmeetingswitch.isThere, users.name AS user FROM gtmeetingswitch
        INNER JOIN users ON users.id = gtmeetingswitch.user
      WHERE gtmeetingswitch.meeting = _meetingId
      ORDER BY gtmeetingswitch.meeting, gtmeetingswitch.user;
    END;

