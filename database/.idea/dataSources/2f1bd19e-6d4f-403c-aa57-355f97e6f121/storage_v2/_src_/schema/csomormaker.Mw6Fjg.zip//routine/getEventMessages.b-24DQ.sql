create
    definer = root@localhost procedure getEventMessages(IN _eventId int)
BEGIN
      SELECT eventmessages.id, eventmessages.sender AS senderId, eventmessages.event AS eventId, eventmessages.dateOfSent, eventmessages.message, users.name AS sender FROM eventmessages
        INNER JOIN users ON eventmessages.sender = users.id
        WHERE event = _eventId
      ORDER BY dateOfSent;
    END;

