create
    definer = root@localhost procedure getWorkStatuses(IN _worker int, IN _event int)
BEGIN
    SELECT users.id AS workerId, users.name AS worker, eventworks.id AS workId, eventworks.name AS work, eventworkworkerswitch.isValid FROM eventworkworkerswitch
      INNER JOIN users ON eventworkworkerswitch.worker = users.id
      INNER JOIN eventworks ON eventworkworkerswitch.work = eventworks.id
    WHERE eventworkworkerswitch.worker = _worker AND eventworks.event = _event;
    END;

