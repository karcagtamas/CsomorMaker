create
    definer = root@localhost procedure getHashById(IN _userId varchar(50))
BEGIN
      SELECT password AS hash FROM users
        WHERE id = _userId AND NOT blocked;
    END;

