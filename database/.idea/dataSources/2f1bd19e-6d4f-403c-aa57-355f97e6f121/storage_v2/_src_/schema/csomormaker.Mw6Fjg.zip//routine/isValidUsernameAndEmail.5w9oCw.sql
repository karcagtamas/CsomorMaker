create
    definer = root@localhost procedure isValidUsernameAndEmail(IN _username varchar(100), IN _email varchar(255))
BEGIN
      DECLARE countOf int(11) DEFAULT 0;
      SELECT COUNT(*) INTO countOf FROM users WHERE username = _username AND email = _email AND NOT blocked;
    IF countOf = 1
      THEN SELECT id AS userId, TRUE AS isValid FROM users WHERE username = _username AND email = _email;
      ELSE SELECT FALSE AS isValid;
      END IF;
    END;

