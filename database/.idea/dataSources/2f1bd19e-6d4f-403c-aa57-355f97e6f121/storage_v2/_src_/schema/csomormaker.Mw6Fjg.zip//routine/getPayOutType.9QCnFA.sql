create
    definer = root@localhost procedure getPayOutType(IN _id int)
BEGIN
     SELECT * FROM eventpayouttypes WHERE id = _id;
    END;

