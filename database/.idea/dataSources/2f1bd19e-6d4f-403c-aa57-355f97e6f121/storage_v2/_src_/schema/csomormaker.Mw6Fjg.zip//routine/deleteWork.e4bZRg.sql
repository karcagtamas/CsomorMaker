create
    definer = root@localhost procedure deleteWork(IN _id int)
BEGIN
    DECLARE _eventId int(11);
    SELECT event INTO _eventId FROM eventworks WHERE id = _id;
   /* DELETE FROM worktables WHERE work = _id;*/
    DELETE FROM eventworks WHERE id = _id;
    CALL setUnReadyEvent(_eventId);
    END;

