create
    definer = root@localhost procedure deleteGtClassMember(IN _memberId int)
BEGIN
    DELETE FROM gtclassmembers WHERE id = _memberId;
  END;

