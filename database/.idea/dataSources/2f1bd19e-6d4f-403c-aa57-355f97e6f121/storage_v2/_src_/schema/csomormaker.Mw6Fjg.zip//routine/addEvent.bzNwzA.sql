create
    definer = root@localhost procedure addEvent(IN _name varchar(50), IN _creater int)
BEGIN
     INSERT INTO events (name, creater, lastUpdater)
      VALUES (_name, _creater, _creater);

     CALL addUserToEvent(_creater, LAST_INSERT_ID(), 1);
    END;

