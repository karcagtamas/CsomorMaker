create
    definer = root@localhost procedure addGtQuestion(IN _gtId int, IN _creater int, IN _question varchar(255))
BEGIN
      INSERT INTO gtquestions(question, creater, lastUpdater, gt)
        VALUES(_question, _creater, _creater, _gtId);
    END;

