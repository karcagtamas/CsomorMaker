create
    definer = root@localhost procedure getPayOutTypes()
BEGIN
     SELECT * FROM eventpayouttypes;
    END;

