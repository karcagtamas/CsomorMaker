create
    definer = root@localhost procedure addNotification(IN _text text, IN _owner int)
BEGIN
      INSERT INTO notifications (text, date, owner)
  VALUES (_text, NOW(), _owner);
  END;

