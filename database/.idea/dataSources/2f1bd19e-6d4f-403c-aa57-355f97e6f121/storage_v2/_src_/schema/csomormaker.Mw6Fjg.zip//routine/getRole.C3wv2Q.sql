create
    definer = root@localhost procedure getRole(IN _id int)
BEGIN
      SELECT * FROM roles WHERE roles.id = _id;
    END;

