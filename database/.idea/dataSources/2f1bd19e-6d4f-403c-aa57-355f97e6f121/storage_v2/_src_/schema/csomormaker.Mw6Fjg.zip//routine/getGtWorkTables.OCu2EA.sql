create
    definer = root@localhost procedure getGtWorkTables(IN _workId int)
BEGIN
      SELECT users.id AS workerId, users.name AS worker, users.username, gtworks.id AS workId, gtworks.name as work, gtworks.gt from gtworktables
      INNER JOIN users ON users.id = gtworktables.worker
      INNER JOIN gtworks ON gtworks.id = gtworktables.work
      WHERE gtworktables.work = _workId;
    END;

