create
    definer = root@localhost procedure addRole(IN _name varchar(100))
BEGIN
      INSERT INTO roles (name)
      VALUES (_name);
    END;

