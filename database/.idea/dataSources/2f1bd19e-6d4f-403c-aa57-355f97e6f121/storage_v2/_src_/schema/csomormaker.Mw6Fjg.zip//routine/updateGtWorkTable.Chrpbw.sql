create
    definer = root@localhost procedure updateGtWorkTable(IN _workId int, IN _workerId int)
BEGIN
      INSERT INTO gtworktables(work, worker)
        VALUES (_workId, _workerId);
    END;

