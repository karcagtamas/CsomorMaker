create
    definer = root@localhost procedure getNotifications(IN _user int)
BEGIN
      SELECT notifications.id, notifications.text, notifications.date, notifications.owner AS ownerId, users.name AS owner FROM notifications
        INNER JOIN users ON notifications.owner = users.id
        WHERE notifications.owner = _user
      ORDER BY notifications.date DESC
      LIMIT 30;
    END;

