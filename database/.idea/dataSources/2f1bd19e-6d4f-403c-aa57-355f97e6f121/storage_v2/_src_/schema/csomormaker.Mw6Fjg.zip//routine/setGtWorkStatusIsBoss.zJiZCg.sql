create
    definer = root@localhost procedure setGtWorkStatusIsBoss(IN _workerId int, IN _workId int)
BEGIN
      DECLARE _boss boolean;
      DECLARE _gtId int(11);
        SELECT isBoss INTO _boss FROM gtworkworkerswitch WHERE worker = _workerId AND work = _workId;

        IF _boss
        THEN
            SET _boss = FALSE;
        ELSE
            SET _boss = TRUE;
        END IF;
        UPDATE gtworkworkerswitch SET isBoss = _boss WHERE worker = _workerId AND work = _workId;
        SELECT gt INTO _gtId FROM gtworks WHERE id = _workId;
        CALL setGtReadyStatus(_gtId, FALSE);
    END;

