create
    definer = root@localhost procedure getGtMeetings(IN _gtId int)
BEGIN
      SELECT gtmeetings.id, gtmeetings.date, gtmeetings.creater AS createrId, users.name AS creater, gtmeetings.gt FROm gtmeetings
        INNER JOIN users ON users.id = gtmeetings.creater
      WHERE gtmeetings.gt = _gtId;
    END;

