create definer = root@localhost trigger gt_members_de
    after DELETE
    on usergtswitch
    for each row
BEGIN
    DECLARE gt int(4);
    SELECT year INTO gt FROM gts WHERE id = OLD.gt;
    CALL addNotification(CONCAT('Eltávolította a következőt gólyatáborból: ', gt, '!'), OLD.user);
    UPDATE gts SET members = members - 1 WHERE id = OLD.gt;
    DELETE FROM gtworkworkerswitch
    WHERE worker = OLD.user AND gtworkworkerswitch.gt = OLD.gt;
    DELETE FROM gtworkertables WHERE worker = OLD.user AND gtworkertables.gt = OLD.gt;
    CALL setGtReadyStatus(OLD.gt, FALSE);
    DELETE FROM gtmeetingswitch WHERE user = OLD.user;
    DELETE FROM gtpresentingsswitch WHERE gt = OLD.gt AND (presenter = OLD.user OR presented = OLD.user);
  END;

