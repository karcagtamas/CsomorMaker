create
    definer = root@localhost procedure lockGt(IN _gtId int)
BEGIN
     DECLARE _lock boolean;
     SELECT isLocked INTO _lock FROM gts WHERE id = _gtId;

     IF _lock
      THEN
        SET _lock = FALSE;
      ELSE
        SET _lock = TRUE;
      END IF;
      UPDATE gts SET isLocked = _lock WHERE id = _gtId;
    END;

