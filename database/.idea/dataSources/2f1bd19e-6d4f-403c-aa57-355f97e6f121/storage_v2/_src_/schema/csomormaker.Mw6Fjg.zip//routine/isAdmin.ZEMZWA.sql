create
    definer = root@localhost procedure isAdmin(IN _userId int)
BEGIN
      DECLARE level int(1) DEFAULT -1;
      DECLARE roleId int(11);
      SELECT role INTO roleId FROM users WHERE id = _userId AND NOT blocked;
      SELECT accessLevel INTO level FROM roles WHERE id = roleId;
      IF level = 3
        THEN SELECT TRUE AS isAdmin;
        ELSE SELECT FALSE AS isAdmin;
        END IF;
    END;

