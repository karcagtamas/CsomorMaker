create definer = root@localhost trigger gt_insert
    after INSERT
    on gts
    for each row
BEGIN
    CALL addNotification(CONCAT('Sikeres létrejött a következeõ gólyatáborod: ', NEW.year), NEW.creater);
  END;

