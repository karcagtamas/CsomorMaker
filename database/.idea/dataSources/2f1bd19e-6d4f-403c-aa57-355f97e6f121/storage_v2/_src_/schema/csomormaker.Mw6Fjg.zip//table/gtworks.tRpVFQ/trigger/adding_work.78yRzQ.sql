create definer = root@localhost trigger adding_work
    after INSERT
    on gtworks
    for each row
BEGIN
    INSERT INTO gtworkworkerswitch (worker, work, gt)
       SELECT * FROM (
        SELECT users.id FROM users
        INNER JOIN usergtswitch ON users.id = usergtswitch.user
        WHERE usergtswitch.gt = NEW.gt) AS T1
    CROSS JOIN (SELECT NEW.id) AS T2 CROSS JOIN (SELECT NEW.gt) AS T3;
    CALL setGtReadyStatus(NEW.id, FALSE);
  END;

