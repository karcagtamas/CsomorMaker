create
    definer = root@localhost procedure decreaseVisitors(IN _id int)
BEGIN
      UPDATE events SET visitors = visitors - 1 WHERE id = _id;
    END;

