create
    definer = root@localhost procedure getNotMembers(IN _event int)
BEGIN
      SELECT users.id, users.username, users.name, users.role AS roleId, roles.name AS role FROM users
        INNER JOIN roles ON users.role = roles.id
      WHERE users.id NOT IN (
      SELECT user as id FROM usereventswitch
      WHERE event = _event
      );
    END;

