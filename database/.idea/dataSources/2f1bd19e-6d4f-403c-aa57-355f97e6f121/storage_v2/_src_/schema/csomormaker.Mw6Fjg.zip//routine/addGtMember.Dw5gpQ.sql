create
    definer = root@localhost procedure addGtMember(IN _gtId int, IN _userId int, IN _roleId int)
BEGIN
      INSERT INTO usergtswitch(gt, user, role) VALUES(_gtId, _userId, _roleId);
    END;

