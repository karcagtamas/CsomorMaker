create
    definer = root@localhost procedure gtAccessLevel(IN _gtId int, IN _userId int)
BEGIN
      SELECT eventroles.accessLevel FROM eventroles
      INNER JOIN usergtswitch ON usergtswitch.role = eventroles.id
      INNER JOIN gts ON usergtswitch.gt = gts.id
      WHERE usergtswitch.user = _userId AND usergtswitch.gt = _gtId;
    END;

