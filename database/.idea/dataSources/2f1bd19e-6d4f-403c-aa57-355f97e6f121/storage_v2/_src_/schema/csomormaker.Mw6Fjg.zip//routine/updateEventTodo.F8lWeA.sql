create
    definer = root@localhost procedure updateEventTodo(IN _todoId int, IN _text longtext, IN _importance int, IN _expDate date)
BEGIN
      UPDATE eventtodoes SET text = _text, importance = _importance, expirationDate = _expDate WHERE id = _todoId;
    END;

