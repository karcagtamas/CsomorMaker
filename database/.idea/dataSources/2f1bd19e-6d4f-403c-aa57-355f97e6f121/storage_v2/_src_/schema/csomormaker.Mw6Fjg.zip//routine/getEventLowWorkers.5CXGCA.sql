create
    definer = root@localhost procedure getEventLowWorkers(IN _id int)
BEGIN
     SELECT users.id, users.name, eventroles.id AS roleId, eventroles.accessLevel, eventroles.name AS role, usereventswitch.connectionDate, usereventswitch.event FROM users
      INNER JOIN usereventswitch ON users.id = usereventswitch.user
      INNER JOIN eventroles ON usereventswitch.role = eventroles.id
       WHERE usereventswitch.event = _id AND eventroles.accessLevel = 1;
    END;

