create
    definer = root@localhost procedure getGtWorks(IN _gtId int)
BEGIN
      SELECT * from gtworks
      WHERE gt = _gtId
      ORDER BY name;
    END;

