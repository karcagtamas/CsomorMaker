create
    definer = root@localhost procedure addGtAnswer(IN _questionId int, IN _answer text, IN _creater varchar(100))
BEGIN
      INSERT INTO gtanswers(answer, question, creater)
        VALUES(_answer, _questionId, _creater);
    END;

