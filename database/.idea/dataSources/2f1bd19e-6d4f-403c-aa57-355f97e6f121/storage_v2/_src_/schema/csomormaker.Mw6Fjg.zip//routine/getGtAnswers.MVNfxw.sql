create
    definer = root@localhost procedure getGtAnswers(IN _questionId int)
BEGIN
      SELECT * FROM gtanswers WHERE question = _questionId;
    END;

