create
    definer = root@localhost procedure addNews(IN _text text, IN _creater int)
BEGIN
      INSERT INTO news (text, date, creater, lastUpdate, lastUpdater)
  VALUES (_text, NOW(), _creater, NOW(), _creater);
    END;

