create
    definer = root@localhost procedure disableEvent(IN _eventId int)
BEGIN
        UPDATE events SET isDisabled = TRUE WHERE id = _eventId;
    END;

