create
    definer = root@localhost procedure getCountOfFixCostsAndDeposits(IN _event int)
BEGIN
       DECLARE costs int(11) DEFAULT 0;
       DECLARE deposits int(11) DEFAULT 0;

       SELECT COUNT(id) INTO costs FROM eventteams WHERE event = _event AND isPaidFixCost;
       SELECT COUNT(id) INTO deposits FROM eventteams WHERE event = _event AND isPaidFixDeposit;

       SELECT costs AS countOfCost, deposits AS countOfDeposit;
    END;

