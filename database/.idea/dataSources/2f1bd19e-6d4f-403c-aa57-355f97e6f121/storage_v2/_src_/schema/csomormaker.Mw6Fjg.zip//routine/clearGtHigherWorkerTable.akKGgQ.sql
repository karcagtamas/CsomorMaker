create
    definer = root@localhost procedure clearGtHigherWorkerTable(IN _gtId int, IN _workerId int)
BEGIN
    UPDATE gtworkertables SET work = NULL WHERE gt = _gtId AND worker = _workerId;
  END;

