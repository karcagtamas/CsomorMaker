create definer = root@localhost trigger event_members
    after INSERT
    on usereventswitch
    for each row
BEGIN
    DECLARE event varchar(100);
    DECLARE role varchar(100);
    SELECT name INTO event FROM events WHERE id = NEW.event;
    SELECT name INTO role FROM eventroles WHERE id = NEW.role;
    UPDATE events SET members = members + 1 WHERE id = NEW.event;
    CALL addNotification(CONCAT('Felvettek a következő eseménybe: ', event, CONCAT(' mint ', role, '!')), NEW.user);
  END;

