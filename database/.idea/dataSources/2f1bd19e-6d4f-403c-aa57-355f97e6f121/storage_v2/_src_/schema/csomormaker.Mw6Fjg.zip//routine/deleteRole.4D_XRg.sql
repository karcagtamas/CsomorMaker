create
    definer = root@localhost procedure deleteRole(IN _id int)
BEGIN
      DELETE FROM roles WHERE roles.id = _id;
    END;

