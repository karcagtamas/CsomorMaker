create
    definer = root@localhost procedure updateUserRole(IN _userId int, IN _roleId int)
BEGIN
        UPDATE users SET role = _roleId WHERE id = _userId;
    END;

