create
    definer = root@localhost procedure getGt(IN _gtId int)
BEGIN
        SELECT gts.id, gts.year, gts.tShirtColor, gts.days, gts.members, gts.ready, gts.creater AS createrId, gts.isLocked, gts.greeny, gts.greenyCost, users.name AS creater, gts.startDate, gts.lastUpdate, gts.creationDate, gts.lastUpdater AS lastUpdaterId, u2.name AS lastUpdater, gts.isDisabled FROM gts
        INNER JOIN users ON gts.creater = users.id
        INNER JOIN users u2 ON gts.lastUpdater = u2.id
        WHERE gts.id = _gtId AND NOT gts.isDisabled;
    END;

