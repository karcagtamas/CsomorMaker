create
    definer = root@localhost procedure setEventTeamIsPaidFixCostStatus(IN _eventteam int, IN _status tinyint(1))
BEGIN
       UPDATE eventteams SET isPaidFixCost = _status WHERE id = _eventteam;
    END;

