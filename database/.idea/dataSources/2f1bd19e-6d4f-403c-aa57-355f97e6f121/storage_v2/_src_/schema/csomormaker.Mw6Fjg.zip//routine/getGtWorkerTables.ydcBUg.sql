create
    definer = root@localhost procedure getGtWorkerTables(IN _workerId int, IN _gtId int)
BEGIN
      SELECT users.id AS workerId, users.name AS worker, users.username, gtworkertables.day, gtworkertables.hour, gtworks.id AS workId, gtworks.name as work, gtworkertables.gt from gtworkertables
      INNER JOIN users ON users.id = gtworkertables.worker
      LEFT JOIN gtworks ON gtworks.id = gtworkertables.work
      INNER JOIN usergtswitch ON users.id = usergtswitch.user
      WHERE gtworkertables.worker = _workerId AND usergtswitch.gt = _gtId
      ORDER BY day, hour;
    END;

