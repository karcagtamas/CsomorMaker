create
    definer = root@localhost procedure addPayOut(IN _name varchar(75), IN _eventId int, IN _type int, IN _cost decimal,
                                                 IN _source varchar(100), IN _destination varchar(100))
BEGIN
     INSERT INTO eventpayouts (name, eventId, type, cost, source, destination)
        VALUES (_name, _eventId, _type, _cost, _source, _destination);
    END;

