create
    definer = root@localhost procedure setGtMeetingMemberThereStatus(IN _meeting int, IN _user int)
BEGIN
    DECLARE _there boolean;
     SELECT isThere INTO _there FROM gtmeetingswitch WHERE meeting = _meeting AND user = _user;

     IF _there
      THEN
        SET _there = FALSE;
      ELSE
        SET _there = TRUE;
      END IF;
      UPDATE gtmeetingswitch SET isThere = _there WHERE meeting = _meeting AND user = _user;
  END;

