create
    definer = root@localhost procedure updatePresentingAnswer(IN _gtId int, IN _user1 int, IN _user2 int, IN _answer text)
BEGIN
      UPDATE gtpresentingsswitch SET answer = _answer WHERE gt = _gtId AND presenter = _user1 AND presented = _user2;
    END;

