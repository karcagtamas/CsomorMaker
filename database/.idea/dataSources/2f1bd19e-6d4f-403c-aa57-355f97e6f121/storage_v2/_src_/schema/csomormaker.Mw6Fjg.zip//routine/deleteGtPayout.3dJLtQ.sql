create
    definer = root@localhost procedure deleteGtPayout(IN _payoutId int)
BEGIN
    DELETE FROM gtpayouts WHERE id = _payoutId;
  END;

