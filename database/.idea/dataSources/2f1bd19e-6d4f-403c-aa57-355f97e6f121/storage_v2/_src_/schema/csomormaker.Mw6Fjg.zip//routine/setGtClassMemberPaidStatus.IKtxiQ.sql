create
    definer = root@localhost procedure setGtClassMemberPaidStatus(IN _memberId int)
BEGIN
    DECLARE _paid boolean;
     SELECT isPaid INTO _paid FROM gtclassmembers WHERE id = _memberId;

     IF _paid
      THEN
        SET _paid = FALSE;
      ELSE
        SET _paid = TRUE;
      END IF;
      UPDATE gtclassmembers SET isPaid = _paid WHERE id = _memberId;
  END;

