create
    definer = root@localhost procedure increaseVisitors(IN _id int)
BEGIN
      UPDATE events SET visitors = visitors + 1 WHERE id = _id;
    END;

