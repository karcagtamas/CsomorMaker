create
    definer = root@localhost procedure addEventMessage(IN _eventId int, IN _text longtext, IN _sender int)
BEGIN
      INSERT INTO eventmessages (event, message, sender) VALUES (_eventId, _text, _sender);
    END;

