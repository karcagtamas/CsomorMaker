create
    definer = root@localhost procedure getEventAccessLevel(IN _user int, IN _event int)
BEGIN
     SELECT eventroles.accessLevel FROM eventroles
      INNER JOIN usereventswitch ON usereventswitch.role = eventroles.id
      INNER JOIN events ON usereventswitch.event = events.id
      WHERE usereventswitch.user = _user AND usereventswitch.event = _event AND NOT events.isDisabled;
    END;

