create
    definer = root@localhost procedure getGtMembers(IN _gtId int)
BEGIN
      SELECT usergtswitch.gt, users.name AS user, users.username AS username, users.id AS userId, usergtswitch.role AS roleId, usergtswitch.connectionDate, eventroles.name AS role, eventroles.accessLevel, users.email, users.tShirtSize, users.class FROM usergtswitch
      INNER JOIN users ON users.id = usergtswitch.user
      INNER JOIN eventroles ON eventroles.id = usergtswitch.role
      WHERE usergtswitch.gt = _gtId
      ORDER BY eventroles.accessLevel DESC, users.name;
    END;

