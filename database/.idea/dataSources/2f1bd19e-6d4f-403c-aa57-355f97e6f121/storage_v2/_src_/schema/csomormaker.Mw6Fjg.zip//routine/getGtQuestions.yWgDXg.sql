create
    definer = root@localhost procedure getGtQuestions(IN _gtId int)
BEGIN
      SELECT gtquestions.id, gtquestions.question, gtquestions.creater AS createrId, user1.name AS creater, gtquestions.gt, gtquestions.creationDate, gtquestions.lastUpdate, gtquestions.lastUpdater AS lastUpdaterId, user2.name AS lastUpdater FROM gtquestions
        INNER JOIN users AS user1 ON user1.id = gtquestions.creater
        INNER JOIN users AS user2 ON user2.id = gtquestions.lastUpdater
      WHERE gtquestions.gt = _gtId;
    END;

