create
    definer = root@localhost procedure getGtPresentingForUser(IN _gtId int, IN _user int)
BEGIN
      SELECT user1.id AS presenterId, user1.name AS presenter, user2.id AS presentedId, user2.name AS presented, gtpresentingsswitch.gt, gtpresentingsswitch.isLicensed, gtpresentingsswitch.answer FROM gtpresentingsswitch
      INNER JOIN users as user1 ON gtpresentingsswitch.presenter = user1.id
      INNER JOIN users As user2 ON gtpresentingsswitch.presented = user2.id
      WHERE gtpresentingsswitch.gt = _gtId AND user1.id = _user AND gtpresentingsswitch.presenter <> gtpresentingsswitch.presented AND gtpresentingsswitch.isLicensed
      ORDER BY presenter, presented;
    END;

