create
    definer = root@localhost procedure clearGtWorkTable(IN _workId int)
BEGIN
      DELETE FROM gtworktables WHERE work = _workId;
    END;

