create
    definer = root@localhost procedure deleteGtWork(IN _workId int)
BEGIN
      DELETE FROM gtworks WHERE id = _workId;
    END;

