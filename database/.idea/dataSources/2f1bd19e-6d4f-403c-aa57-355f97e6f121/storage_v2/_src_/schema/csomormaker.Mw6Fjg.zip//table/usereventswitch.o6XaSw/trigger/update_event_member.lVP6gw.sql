create definer = root@localhost trigger update_event_member
    after UPDATE
    on usereventswitch
    for each row
BEGIN
    DECLARE event varchar(100);
    DECLARE role varchar(100);
    SELECT name INTO event FROM events WHERE id = NEW.event;
    SELECT name INTO role FROM eventroles WHERE id = NEW.role;
    CALL addNotification(CONCAT(event, ' eseményben megváltozott a rangod a következőre: ', role), NEW.user);
  END;

