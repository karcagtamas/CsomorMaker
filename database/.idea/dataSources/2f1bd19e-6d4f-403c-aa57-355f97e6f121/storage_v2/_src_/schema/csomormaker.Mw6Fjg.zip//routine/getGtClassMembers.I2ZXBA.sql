create
    definer = root@localhost procedure getGtClassMembers(IN _classId int)
BEGIN
    SELECT gtclassmembers.id, gtclassmembers.class AS classId, gtclassmembers.name, gtclassmembers.isPaid, gtclassmembers.description, gtclasses.name AS class, gtclassmembers.allergy, gtclassmembers.tShirtSize FROM gtclassmembers
      INNER JOIN gtclasses ON gtclasses.id = gtclassmembers.class
      WHERE gtclassmembers.class = _classId
      ORDER BY name;
  END;

