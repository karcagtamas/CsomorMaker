create
    definer = root@localhost procedure getGtClasses(IN _gtId int)
BEGIN
    SELECT * FROM gtclasses
      WHERE gt = _gtId
      ORDER BY name;
  END;

