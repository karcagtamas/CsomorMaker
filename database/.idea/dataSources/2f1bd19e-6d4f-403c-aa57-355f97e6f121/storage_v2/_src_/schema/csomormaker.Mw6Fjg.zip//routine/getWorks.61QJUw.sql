create
    definer = root@localhost procedure getWorks(IN _eventId int)
BEGIN
     SELECT * FROM eventworks WHERE event = _eventId;
    END;

