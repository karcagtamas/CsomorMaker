create
    definer = root@localhost procedure addEventTodo(IN _eventId int, IN _text longtext, IN _importance int(1),
                                                    IN _expDate datetime)
BEGIN
      INSERT INTO eventtodoes (event, text, expirationDate, importance) VALUES (_eventId, _text, _expDate, _importance);
    END;

