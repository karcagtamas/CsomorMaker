create
    definer = root@localhost procedure getPayOut(IN _id int)
BEGIN
    SELECT  eventpayouts.name, eventpayouts.id, eventpayouts.eventId, eventpayouts.cost, eventpayouts.type AS typeId, eventpayouttypes.name AS type, eventpayouttypes.isOut, eventpayouts.source, eventpayouts.destination FROM eventpayouts
     INNER JOIN eventpayouttypes ON eventpayouts.type = eventpayouttypes.id
     WHERE eventpayouts.id = _id;
    END;

