create
    definer = root@localhost procedure getAllEvent()
BEGIN
        SELECT events.id, 
        events.name,
        events.isLocked, 
        events.isDisabled, 
        events.currentPlayers, 
        events.injured, 
        events.visitors, 
        events.visitorLimit, 
        events.playerCost, 
        events.visitorCost, 
        events.playerDeposit, 
        events.days, 
        events.startHour, 
        events.endHour, 
        events.length, 
        events.ready, 
        events.creationDate,
        events.members,
        events.creater AS createId, 
        users.name AS creater, 
        events.startDate,
        events.lastUpdate,
        events.lastUpdater AS lastUpdaterId,
        u2.name AS lastUpdater,
        events.fixTeamCost,
        events.fixTeamDeposit
        FROM events
        INNER JOIN users ON events.creater = users.id
        INNER JOIN users u2 ON events.lastUpdater = u2.id;
    END;

