create definer = root@localhost trigger gt_meetings_delete
    after DELETE
    on gtmeetings
    for each row
BEGIN
    DELETE FROM gtmeetingswitch WHERE meeting = OLD.id;
  END;

