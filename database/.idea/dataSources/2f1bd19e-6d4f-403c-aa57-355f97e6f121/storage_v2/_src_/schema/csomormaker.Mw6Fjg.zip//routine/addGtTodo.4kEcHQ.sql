create
    definer = root@localhost procedure addGtTodo(IN _gtId int, IN _text longtext, IN _importance int(1),
                                                 IN _expirationDate datetime)
BEGIN
    INSERT INTO gttodoes(gt, text, importance, expirationDate)
      VALUES(_gtId, _text, _importance, _expirationDate);
  END;

