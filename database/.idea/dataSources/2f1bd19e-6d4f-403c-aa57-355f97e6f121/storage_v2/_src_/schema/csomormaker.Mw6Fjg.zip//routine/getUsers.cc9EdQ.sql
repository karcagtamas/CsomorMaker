create
    definer = root@localhost procedure getUsers()
BEGIN
     SELECT users.id, users.name, users.username, users.email, users.role AS roleId, roles.name AS role, users.tShirtSize, users.allergy, users.lastLogin, users.class, users.registrationTime, users.blocked FROM users
     INNER JOIN roles ON users.role = roles.id;
    END;

