create
    definer = root@localhost procedure addEventTeam(IN _eventId int, IN _name varchar(100))
BEGIN
      INSERT INTO eventteams (name, event)
        VALUES (_name, _eventId);
    END;

