create definer = root@localhost trigger news_update
    after UPDATE
    on news
    for each row
BEGIN
    DECLARE _updater varchar(100);
    DECLARE _creater varchar(100);
    SELECT username INTO _updater FROM users WHERE id = NEW.lastUpdater;
    SELECT username INTO _creater FROM users WHERE id = NEW.creater;
    CALL addNotification(CONCAT('Az egyik híredet szerkesztette ', _updater, ' nevű felhasználó!'), OLD.creater);
    CALL addNotification(CONCAT('Szerkesztetted ', _updater, ' nevű felhasználó hírét!'), NEW.lastUpdater);
  END;

