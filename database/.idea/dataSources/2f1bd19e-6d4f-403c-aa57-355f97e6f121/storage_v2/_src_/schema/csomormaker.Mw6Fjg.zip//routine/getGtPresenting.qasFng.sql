create
    definer = root@localhost procedure getGtPresenting(IN _gtId int)
BEGIN
      SELECT user1.id AS presenterId, user1.name AS presenter, user2.id AS presentedId, user2.name AS presented, gtpresentingsswitch.gt, gtpresentingsswitch.isLicensed, gtpresentingsswitch.answer FROM gtpresentingsswitch
      INNER JOIN users as user1 ON gtpresentingsswitch.presenter = user1.id
      INNER JOIN users As user2 ON gtpresentingsswitch.presented = user2.id
      WHERE gt = _gtId
      ORDER BY presenter, presented;
    END;

