create
    definer = root@localhost procedure addGtClass(IN _gtId int, IN _name varchar(5))
BEGIN
    INSERT INTO gtclasses (name, gt)
      VALUES(_name, _gtId);
  END;

