create
    definer = root@localhost procedure deleteGtTodo(IN _todoId int)
BEGIN
    DELETE FROM gttodoes WHERE id = _todoId;
  END;

