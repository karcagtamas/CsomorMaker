create
    definer = root@localhost procedure addGtClassMember(IN _classId int, IN _name varchar(100), IN _description text,
                                                        IN _allergy text, IN _tShirtSize varchar(6))
BEGIN
    INSERT INTO gtclassmembers (name, description, class, allergy, tShirtSize)
      VALUES(_name,_description, _classId, _allergy, _tShirtSize);
  END;

