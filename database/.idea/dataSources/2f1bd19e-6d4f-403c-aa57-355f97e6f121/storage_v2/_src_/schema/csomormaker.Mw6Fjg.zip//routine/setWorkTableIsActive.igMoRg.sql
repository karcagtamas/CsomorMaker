create
    definer = root@localhost procedure setWorkTableIsActive(IN _day int(2), IN _hour int(2), IN _work int)
BEGIN
       DECLARE _eventId int(11);
     DECLARE _isActive boolean;
      SELECT event INTO _eventId FROM eventworks WHERE id = _work;
     SELECT isActive INTO _isActive FROM eventworktables WHERE day = _day AND hour = _hour AND work = _work;

     IF _isActive
      THEN
        SET _isActive = FALSE;
      ELSE
        SET _isActive = TRUE;
      END IF;
      UPDATE eventworktables SET isActive = _isActive WHERE day = _day AND hour = _hour AND work = _work;
      CALL setUnReadyEvent(_eventId);
    END;

