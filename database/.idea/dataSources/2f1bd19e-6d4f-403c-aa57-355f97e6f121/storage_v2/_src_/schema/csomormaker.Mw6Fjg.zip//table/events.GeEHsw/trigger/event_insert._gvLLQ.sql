create definer = root@localhost trigger event_insert
    after INSERT
    on events
    for each row
BEGIN
    CALL addNotification(CONCAT('Sikeres létrejött a következő eseményed: ', NEW.name), NEW.creater);
  END;

