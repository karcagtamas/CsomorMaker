create
    definer = root@localhost procedure countOfAllPaid(IN _gtId int)
BEGIN
     SELECT COUNT(gtclassmembers.id) AS countOfCosts  FROM gtclassmembers
      INNER JOIN gtclasses ON gtclassmembers.class = gtclasses.id
    WHERE gtclasses.gt = _gtId AND gtclassmembers.isPaid;
    END;

