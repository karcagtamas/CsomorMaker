create
    definer = root@localhost procedure updateGtClass(IN _classId int, IN _name varchar(5), IN _tShirtColor varchar(50),
                                                     IN _master varchar(100))
BEGIN
    UPDATE gtclasses SET name = _name, tShirtColor = _tShirtColor, classMaster = _master WHERE id = _classId;
  END;

