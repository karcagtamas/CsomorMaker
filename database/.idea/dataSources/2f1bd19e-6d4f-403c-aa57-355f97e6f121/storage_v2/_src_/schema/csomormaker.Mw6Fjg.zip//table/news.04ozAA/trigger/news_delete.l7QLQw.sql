create definer = root@localhost trigger news_delete
    after DELETE
    on news
    for each row
BEGIN
    CALL addNotification('Az egyik híred törlésre került!', OLD.creater);
  END;

