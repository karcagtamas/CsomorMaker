create
    definer = root@localhost procedure decreaseInjured(IN _id int)
BEGIN
      UPDATE events SET injured = injured - 1 WHERE id = _id;
    END;

