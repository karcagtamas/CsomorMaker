create
    definer = root@localhost procedure setEventTeamIsPaidFixDepositStatus(IN _eventteam int, IN _status tinyint(1))
BEGIN
       UPDATE eventteams SET isPaidFixDeposit = _status WHERE id = _eventteam;
    END;

