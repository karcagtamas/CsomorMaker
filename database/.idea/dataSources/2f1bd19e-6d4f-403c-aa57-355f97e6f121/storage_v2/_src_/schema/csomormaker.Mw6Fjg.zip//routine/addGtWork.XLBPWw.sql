create
    definer = root@localhost procedure addGtWork(IN _gtId int, IN _name varchar(100), IN _day int(2), IN _start int(2),
                                                 IN _end int(2), IN _workers int(3))
BEGIN
      INSERT INTO gtworks(name, day, startHour, endHour, gt, workerCount)
      VALUES (_name, _day, _start, _end, _gtId, _workers);
    END;

