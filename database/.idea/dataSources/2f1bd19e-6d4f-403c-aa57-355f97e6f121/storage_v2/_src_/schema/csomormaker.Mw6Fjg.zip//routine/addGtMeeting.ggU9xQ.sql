create
    definer = root@localhost procedure addGtMeeting(IN _date date, IN _creater int, IN _gt int)
BEGIN
      INSERT INTO gtmeetings(date, creater, gt)
      VALUES (_date, _creater, _gt);
    END;

