create
    definer = root@localhost procedure deleteEventTeamMember(IN _teammemberId int)
BEGIN
      DELETE FROM eventteammembers WHERE id = _teammemberId;
    END;

