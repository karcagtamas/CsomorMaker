create definer = root@localhost trigger gt_members_update
    after UPDATE
    on usergtswitch
    for each row
BEGIN
    DECLARE gt int(4);
    DECLARE role varchar(100);
    IF NEW.role <> OLD.role
      THEN
    SELECT year INTO gt FROM gts WHERE id = NEW.gt;
    SELECT name INTO role FROM eventroles WHERE id = NEW.role;
    CALL addNotification(CONCAT(gt, ' gólyatáborban megváltozott a rangod a következőre: ', role), NEW.user);
    END IF;
    CALL setGtReadyStatus(OLD.gt, FALSE);
  END;

