create
    definer = root@localhost procedure getEventRoles()
BEGIN
        SELECT * FROM eventroles;
     END;

