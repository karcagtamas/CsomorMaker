create
    definer = root@localhost procedure updateEvent(IN _id int, IN _name varchar(50), IN _injured int, IN _visitors int,
                                                   IN _visitorLimit int, IN _playerCost decimal,
                                                   IN _visitorCost decimal, IN _playerDeposit decimal, IN _days int(2),
                                                   IN _startHour int(2), IN _endHour int(2), IN _length int(4),
                                                   IN _startDate date, IN _updater int, IN _fixTeamCost decimal(8, 5),
                                                   IN _fixTeamDeposit decimal(8, 5))
BEGIN
     UPDATE events SET 
      name = _name,
      injured = _injured,
      visitors = _visitors,
      visitorLimit = _visitorLimit,
      playerCost = _playerCost,
      visitorCost = _visitorCost,
      playerDeposit = _playerDeposit,
      days = _days,
      startHour = _startHour,
      endHour = _endHour,
      length = _length,
      startDate = _startDate,
      lastUpdater = _updater,
      lastUpdate = NOW(),
      fixTeamCost = _fixTeamCost,
      fixTeamDeposit = _fixTeamDeposit
     WHERE id = _id;
    END;

