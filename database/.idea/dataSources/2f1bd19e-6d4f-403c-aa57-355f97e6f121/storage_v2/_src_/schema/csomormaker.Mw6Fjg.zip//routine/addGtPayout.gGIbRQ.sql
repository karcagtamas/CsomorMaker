create
    definer = root@localhost procedure addGtPayout(IN _gtId int, IN _name varchar(75), IN _type int, IN _cost decimal,
                                                   IN _from varchar(50), IN _to varchar(50))
BEGIN
    INSERT INTO gtpayouts(name, gt, type, cost, source, destination)
      VALUES(_name, _gtId, _type, _cost, _from, _to);
  END;

