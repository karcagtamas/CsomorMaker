create
    definer = root@localhost procedure setSolvedEventTodo(IN _todoId int)
BEGIN
      UPDATE eventtodoes SET isSolved = TRUE WHERE id = _todoId;
    END;

