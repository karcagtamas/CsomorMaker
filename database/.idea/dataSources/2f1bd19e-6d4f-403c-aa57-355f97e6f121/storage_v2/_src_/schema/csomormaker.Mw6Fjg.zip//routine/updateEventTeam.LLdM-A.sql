create
    definer = root@localhost procedure updateEventTeam(IN _teamId int, IN _name varchar(100))
BEGIN
      UPDATE eventteams SET name = _name WHERE id = _teamId;
    END;

