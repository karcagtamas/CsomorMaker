create definer = root@localhost trigger user_update
    after UPDATE
    on users
    for each row
BEGIN
    DECLARE _role varchar(100);
    IF NEW.role <> OLD.role
      THEN
      SELECT name INTO _role FROM roles WHERE id = NEW.role;
      CALL addNotification(CONCAT('Megváltozott a szerver rangod a következőre: ', _role), NEW.id);
    END IF;
    IF NEW.name <> OLD.name
      THEN
      CALL addNotification(CONCAT('Megváltozott a neved következőre: ', NEW.name), NEW.id);
    END IF;
    IF NEW.email <> OLD.email
      THEN
      CALL addNotification(CONCAT('Megváltozott az e-mail címed következőre: ', NEW.email), NEW.id);
    END IF;
    IF NEW.password <> OLD.password
      THEN
      CALL addNotification('Megváltozott a neved a jelszavad', NEW.id);
    END IF;
  END;

