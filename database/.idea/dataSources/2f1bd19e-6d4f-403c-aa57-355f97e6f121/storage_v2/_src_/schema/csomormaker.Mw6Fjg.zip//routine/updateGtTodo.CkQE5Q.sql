create
    definer = root@localhost procedure updateGtTodo(IN _todoId int, IN _text longtext, IN _importance int(1),
                                                    IN _expirationDate datetime)
BEGIN
    UPDATE gttodoes SET text = _text, importance = _importance, expirationDate = _expirationDate WHERE id = _todoId;
  END;

