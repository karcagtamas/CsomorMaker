create
    definer = root@localhost procedure setUnReadyEvent(IN _id int)
BEGIN
      UPDATE events SET ready = FALSE WHERE id = _id;
    END;

