create definer = root@localhost trigger news_insert
    after INSERT
    on news
    for each row
BEGIN
    CALL addNotification('A hír hozzáadása sikeres!', NEW.creater);
  END;

