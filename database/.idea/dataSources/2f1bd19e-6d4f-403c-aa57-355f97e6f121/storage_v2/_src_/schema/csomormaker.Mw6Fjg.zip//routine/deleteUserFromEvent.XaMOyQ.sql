create
    definer = root@localhost procedure deleteUserFromEvent(IN _userId int, IN _eventId int)
BEGIN
        DELETE FROM usereventswitch WHERE user = _userId AND event = _eventId;
        DELETE FROM eventworkertables WHERE worker = _userId AND event = _eventId;
        DELETE FROM eventworkworkerswitch WHERE worker = _userId;
     END;

