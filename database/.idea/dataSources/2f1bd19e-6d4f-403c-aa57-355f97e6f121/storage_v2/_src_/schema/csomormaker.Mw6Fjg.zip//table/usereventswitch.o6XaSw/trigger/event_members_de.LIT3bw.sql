create definer = root@localhost trigger event_members_de
    after DELETE
    on usereventswitch
    for each row
BEGIN
    DECLARE event varchar(100);
    SELECT name INTO event FROM events WHERE id = OLD.event;
    UPDATE events SET members = members - 1 WHERE id = OLD.event;
    CALL addNotification(CONCAT('Eltávolítottka a következő eseményből: ', event, '!'), OLD.user);
  END;

