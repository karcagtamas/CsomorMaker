create
    definer = root@localhost procedure getAccessLevel(IN _userId int)
BEGIN
        SELECT roles.accessLevel FROM roles
        INNER JOIN users ON users.role = roles.id
        WHERE users.id = _userId;
    END;

