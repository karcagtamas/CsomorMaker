create
    definer = root@localhost procedure updateGtWorkerTable(IN _gtId int, IN _workerId int, IN _day int(2),
                                                           IN _hour int(2), IN _workId int)
BEGIN
      UPDATE gtworkertables SET work = _workId WHERE gt = _gtId AND worker = _workerId AND day = _day AND hour = _hour;
    END;

