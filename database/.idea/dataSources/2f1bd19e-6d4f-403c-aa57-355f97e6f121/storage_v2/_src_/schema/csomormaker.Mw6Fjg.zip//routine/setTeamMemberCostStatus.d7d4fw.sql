create
    definer = root@localhost procedure setTeamMemberCostStatus(IN _teammemberId int)
BEGIN
     DECLARE _isPaid boolean;
     SELECT isPaidCost INTO _isPaid FROM eventteammembers WHERE id = _teammemberId;

     IF _isPaid
      THEN
        SET _isPaid = FALSE;
      ELSE
        SET _isPaid = TRUE;
      END IF;
      UPDATE eventteammembers SET isPaidCost = _isPaid WHERE id = _teammemberId;
      UPDATE eventteammembers SET isPaidDeposit = _isPaid WHERE id = _teammemberId;
    END;

