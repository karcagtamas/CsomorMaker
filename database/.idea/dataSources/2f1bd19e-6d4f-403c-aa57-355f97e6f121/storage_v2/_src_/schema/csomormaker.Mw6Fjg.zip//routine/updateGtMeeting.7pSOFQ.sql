create
    definer = root@localhost procedure updateGtMeeting(IN _id int, IN _date date)
BEGIN
      UPDATE gtmeetings SET date = _date WHERE id = _id;
    END;

