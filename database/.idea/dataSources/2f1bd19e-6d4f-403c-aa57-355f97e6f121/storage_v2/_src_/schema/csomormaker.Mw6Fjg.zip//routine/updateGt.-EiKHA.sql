create
    definer = root@localhost procedure updateGt(IN _gtId int, IN _year int(4), IN _tShirtColor varchar(50),
                                                IN _days int(2), IN _startDate date, IN _updater int)
BEGIN
        UPDATE gts SET year = _year, tShirtColor = _tShirtColor, days = _days, startDate = _startDate, lastUpdater = _updater, lastUpdate = NOW() WHERE id = _gtId;
    END;

