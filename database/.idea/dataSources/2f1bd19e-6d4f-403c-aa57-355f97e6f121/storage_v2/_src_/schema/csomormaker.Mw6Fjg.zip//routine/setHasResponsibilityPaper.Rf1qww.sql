create
    definer = root@localhost procedure setHasResponsibilityPaper(IN _teamId int)
BEGIN
      DECLARE responsibility int(11);

     SELECT hasResponsibilityPaper INTO responsibility FROM eventteams WHERE id = _teamId;

     IF responsibility
      THEN
        SET responsibility = FALSE;
      ELSE
        SET responsibility = TRUE;
      END IF;
      UPDATE eventteams SET hasResponsibilityPaper = responsibility  WHERE id = _teamId;
  END;

