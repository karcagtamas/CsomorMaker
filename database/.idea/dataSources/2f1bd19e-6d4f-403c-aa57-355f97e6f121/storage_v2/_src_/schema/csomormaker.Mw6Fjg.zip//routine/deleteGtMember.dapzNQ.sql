create
    definer = root@localhost procedure deleteGtMember(IN _gtId int, IN _userId int)
BEGIN
      DELETE FROM usergtswitch WHERE user = _userId AND gt = _gtId;
    END;

