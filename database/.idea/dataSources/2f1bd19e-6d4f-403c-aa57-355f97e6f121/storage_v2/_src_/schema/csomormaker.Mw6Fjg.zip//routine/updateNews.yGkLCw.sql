create
    definer = root@localhost procedure updateNews(IN _id int, IN _text text, IN _updater int)
BEGIN
      UPDATE news SET text = _text, lastUpdater = _updater, lastUpdate = CURRENT_TIMESTAMP WHERE id = _id;
    END;

