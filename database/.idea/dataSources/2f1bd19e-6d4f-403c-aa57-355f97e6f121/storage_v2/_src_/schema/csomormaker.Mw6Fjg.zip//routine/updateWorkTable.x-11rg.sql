create
    definer = root@localhost procedure updateWorkTable(IN _work int, IN _day int(2), IN _hour int, IN _worker int)
BEGIN
      UPDATE eventworktables SET worker = _worker WHERE work = _work AND day = _day AND hour = _hour;
    END;

