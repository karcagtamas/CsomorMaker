create
    definer = root@localhost procedure addGt(IN _year int(4), IN _creater int)
BEGIN
        INSERT INTO gts(year, creater, lastUpdater) VALUES (_year, _creater, _creater);
        CALL addGtMember(LAST_INSERT_ID(), _creater, 1);
    END;

