create
    definer = root@localhost procedure setIsValidWorkStatus(IN _work int, IN _worker int)
BEGIN
      DECLARE _eventId int(11);
     DECLARE _isValid boolean;
      SELECT event INTO _eventId FROM eventworks WHERE id = _work;
     SELECT isValid INTO _isValid FROM eventworkworkerswitch WHERE work = _work AND worker = _worker;

     IF _isValid
      THEN
        SET _isValid = FALSE;
      ELSE
        SET _isValid = TRUE;
      END IF;
      UPDATE eventworkworkerswitch SET isValid = _isValid  WHERE work = _work AND worker = _worker;
  CALL setUnReadyEvent(_eventId);
  END;

